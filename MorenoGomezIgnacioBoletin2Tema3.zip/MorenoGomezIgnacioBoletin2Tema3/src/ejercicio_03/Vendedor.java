package ejercicio_03;

public class Vendedor {
	//atributos
	private Movil[] listado;
	private double	 totalVendido;
	
}
