package ejercicio_01;

public class Gestion {
	
	private Producto[] listaProductos;
	
}
