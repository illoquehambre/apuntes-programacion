package ejercicio;

public interface IAterrizaje {
	
	public double calcularPrecioAterrizaje
	(double precioTam, double limite, double precioExtra, double porcMotores, int limitMotores, double precMisil);
}
