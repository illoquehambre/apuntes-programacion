/**
 * 
 */
/**
 * @author moreno.goign22
 * 
 * El objetivo de este paquete es el de gestionar una inmobiliaria y sus distintos pisos
 * 
 *Este paquete ejercicio constará de 3 clases
 *La clase Principal la cual contendrá el main y mostrará todo
 *La clase Piso la cual tendrá unicamente los atributos de dicho piso y un método calcularMetroCuadrado
 *La clase Inmobiliaria la cual gestionará los distintos pisos guardados en 
 *un array de pisos como atibuto propio y que realizará diversos métodos sobre estos.
 *
 *
 */
package ejercicio;